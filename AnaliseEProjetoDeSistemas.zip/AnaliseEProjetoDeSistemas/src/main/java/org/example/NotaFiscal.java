package org.example;
import java.time.LocalDate;

public class NotaFiscal {

    private int valor;
    private int cnpj;
    private int regimeTributario;
    private int numeroDaNotaFiscal;
    private LocalDate dataDeEmissao;
    private String descricao;
    private String email;
    private String razaoSocial;

    public NotaFiscal(int valor, int cnpj, int regimeTributario, int numeroDaNotaFiscal, LocalDate dataDeEmissao, String descricao, String email, String razaoSocial) {
        this.valor = valor;
        this.cnpj = cnpj;
        this.regimeTributario = regimeTributario;
        this.numeroDaNotaFiscal = numeroDaNotaFiscal;
        this.dataDeEmissao = dataDeEmissao;
        this.descricao = descricao;
        this.email = email;
        this.razaoSocial = razaoSocial;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public int getCnpj() {
        return cnpj;
    }

    public void setCnpj(int cnpj) {
        this.cnpj = cnpj;
    }

    public int getRegimeTributario() {
        return regimeTributario;
    }

    public void setRegimeTributario(int regimeTributario) {
        this.regimeTributario = regimeTributario;
    }

    public int getNumeroDaNotaFiscal() {
        return numeroDaNotaFiscal;
    }

    public void setNumeroDaNotaFiscal(int numeroDaNotaFiscal) {
        this.numeroDaNotaFiscal = numeroDaNotaFiscal;
    }

    public LocalDate getDataDeEmissao() {
        return dataDeEmissao;
    }

    public void setDataDeEmissao(LocalDate dataDeEmissao) {
        this.dataDeEmissao = dataDeEmissao;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    @Override
    public String toString() {
        return "NotaFiscal{" +
                "valor=" + valor +
                ", cnpj=" + cnpj +
                ", regimeTributario=" + regimeTributario +
                ", numeroDaNotaFiscal=" + numeroDaNotaFiscal +
                ", dataDeEmissao=" + dataDeEmissao +
                ", descricao='" + descricao + '\'' +
                ", email='" + email + '\'' +
                ", razaoSocial='" + razaoSocial + '\'' +
                '}';
    }
}
