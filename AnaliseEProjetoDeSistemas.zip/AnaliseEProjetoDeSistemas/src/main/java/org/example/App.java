package org.example;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<NotaFiscal> notasFiscais = new ArrayList<>();

        int opcao;
        do {
            // NF = Nota Fiscal
            System.out.println("1- Cadastrar NF");
            System.out.println("2- Calcular imposto");
            System.out.println("3- Sair");
            opcao = sc.nextInt();

            switch (opcao) {
                case 1:
                    sc.nextLine();
                    System.out.println("Cadastrar NF");
                    System.out.print("Informe o valor: ");
                    int valor = sc.nextInt();
                    System.out.print("Informe o CNPJ: ");
                    int cnpj = sc.nextInt();
                    System.out.print("Informe a Data de Emissão (yyyy-mm-dd): ");
                    String dataInput = sc.next();
                    LocalDate dataDeEmissao = LocalDate.parse(dataInput);
                    System.out.print("Informe o Email: ");
                    String email = sc.next();

                    NotaFiscal notaFiscal = new NotaFiscal(valor, cnpj, 0, 0, dataDeEmissao, "", email, ""); // Placeholder para número da nota e descrição
                    notasFiscais.add(notaFiscal);
                    System.out.println("Nota fiscal cadastrada com sucesso!");
                    break;

                case 2:
                    //SM = Simples Nacional
                    //LP = Lucro presumido

                    System.out.print("Informe o tipo de nota (SM ou LP): ");
                    String tipo = sc.next();
                    System.out.print("Informe o valor da NF: ");
                    valor = sc.nextInt();

                    double imposto = 0;
                    if (tipo.equalsIgnoreCase("SM")) {
                        imposto = valor * 0.065; // 6,5%
                    } else if (tipo.equalsIgnoreCase("LP")) {
                        imposto = valor * 0.12; // 12%
                    } else {
                        System.out.println("Tipo de nota inválido.");
                        break;
                    }

                    System.out.printf("O imposto devido para a nota %s é: R$ %.2f%n", tipo, imposto);
                    break;

                case 3:
                    System.out.println("Saindo...");
                    break;

                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        } while (opcao != 3);

        sc.close();
    }
}
